define( function ( require ) {

	"use strict";

	return {
		app_slug : 'test-app-regan',
		wp_ws_url : 'http://thg.hfnelson.com/wp-appkit-api/test-app-regan',
		theme : 'thg-theme-dev',
		version : '',
		app_title : 'test-app-regan',
		debug_mode : 'off',
		auth_key : ']Hl!B%]+nE(VAtZ*;yxVxnkJu|m_lT;K+fD;Wer<AT<A&*Are@ItjG;J/xu{m$+_+gcmFfBMge!@/asJtG|_[@EH{R&xqi$!uQx>$;@{+rKMjQENiQZ|JaS{Hr|fCj+Q',
		options : {"refresh_interval":0},
		addons : []		
	};

});
