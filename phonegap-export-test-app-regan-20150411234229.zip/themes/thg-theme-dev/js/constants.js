define(function ()
{
	return {
		"SERVER_URL": "http://thg.hfnelson.com/wp-json/",
		"LOGIN_API": "http://thg.hfnelson.com/wp-json/users/me"
	};
 });